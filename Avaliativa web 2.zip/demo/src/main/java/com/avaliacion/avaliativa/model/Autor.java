package com.avaliacion.avaliativa.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;


@Entity
@Table(name="Autor")
public class Autor {
	
	
	
	
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;
	
	private String Nome;
	private String Sobrenome;
	private String generoliterario;


	
	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}




	@NotNull
	private int tipo;
	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	@NotBlank
	

	
	
	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		this.Nome = nome;
	}

	public String getSobrenome() {
		return Sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.Sobrenome = sobrenome;
	}

	public String getGeneroliterario() {
		return generoliterario;
	}

	public void setGeneroliterario(String generoliterario) {
		this.generoliterario = generoliterario;
	}




	
}
