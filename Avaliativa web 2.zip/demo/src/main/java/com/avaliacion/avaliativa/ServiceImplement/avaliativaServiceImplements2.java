package com.avaliacion.avaliativa.ServiceImplement;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avaliacion.avaliativa.model.Autor;
import com.avaliacion.avaliativa.repository.avaliativaRepositorydos;
import com.avaliacion.avaliativa.service.avaliativaServicedos;

@Service
public class avaliativaServiceImplements2 implements avaliativaServicedos {
	@Autowired
	avaliativaRepositorydos avaliativaRepositorydos;

	@Override
	public Autor save(Autor autor) {
		// TODO Auto-generated method stub
		return avaliativaRepositorydos.save(autor);
	}

	

	@Override
	public Autor findById(Integer id) {
		// TODO Auto-generated method stub
		return avaliativaRepositorydos.findById(id).get();
	}

	@Override
	public List<Autor> findAll() {
		// TODO Auto-generated method stub
		 	return avaliativaRepositorydos.findAll();

	}

	@Override
	public Autor deleteById(int id) {
		// TODO Auto-generated method stub
			return deleteById(id);
	}



	@Override
	public List<Autor> findAutorByGeneroliterarioLike(String generoliterario) {
		// TODO Auto-generated method stub
		return avaliativaRepositorydos.findAutorByGeneroliterarioLike(generoliterario);
	}







}
