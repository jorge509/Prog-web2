package com.avaliacion.avaliativa.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.avaliacion.avaliativa.model.Autor;
import com.avaliacion.avaliativa.model.Libro;
import com.avaliacion.avaliativa.repository.avaliativaRepository;
import com.avaliacion.avaliativa.repository.avaliativaRepositorydos;
@Controller
public class avaliativaController {

	@Autowired
	avaliativaRepository avaliativaRepository;

	@Autowired
	avaliativaRepositorydos avaliativaRepositorydos;///declaro repositorio2
	
	@RequestMapping(value="/index",method=RequestMethod.GET)
	public ModelAndView getLibro() {//cambio libro por libroa
		ModelAndView mv= new ModelAndView("index");
		List<Libro> libro=avaliativaRepository.findAll();
		mv.addObject("libro",libro);
		return mv;
	}
	@RequestMapping(value="/libro/{id}",method=RequestMethod.GET)//cambio libro por libros
	public ModelAndView getLibro(@PathVariable("id")int id) {
		ModelAndView mv= new ModelAndView("libro");
		Optional<Libro> libro=avaliativaRepository.findById(id);
		mv.addObject("libro",libro);
		mv.addObject("autor",libro.get().getescritor());
		mv.addObject("titulo",libro.get().getTitulo());
		mv.addObject("data",libro.get().getData());
		
		mv.addObject("id",libro.get().getId());
		return mv;
		
	}

	@RequestMapping(value="/index/save",method=RequestMethod.GET)
	public String save() {

		return "save";
		
	}
	
	
	
	@RequestMapping(value="/index/save",method=RequestMethod.POST)
	public String saveLibro(@Valid Libro libro ,BindingResult result, RedirectAttributes attributes) {
		
		if(result.hasErrors()) {
			attributes.addFlashAttribute("mensagem","verifique os campos obrigatorios");
			return "redirect:/index/save";
			
		}
		
		
		
		libro.setData(LocalDate.now());
		avaliativaRepository.save(libro);
		attributes.addFlashAttribute("mensagem","Sucess");

		
		
		return "redirect:/index";
	}
	
	
	
	
	@RequestMapping(value="/libro/update/{id}",method=RequestMethod.GET)
	public ModelAndView updateLibro(@PathVariable("id")int id) {
		ModelAndView mv= new ModelAndView("Update");
		Optional<Libro> libro=avaliativaRepository.findById(id);
		mv.addObject("libros",libro);
		mv.addObject("tipo",libro.get().getTipo());
		mv.addObject("titulo",libro.get().getTitulo());
		mv.addObject("escritor",libro.get().getEscritor());
		
	
		mv.addObject("id",libro.get().getId());
		return mv;
		
	}
	
	@RequestMapping(value="/libro/update/{id}",method=RequestMethod.POST)
	public String updateLibro(Libro libro) {
		Libro libroexistente =avaliativaRepository.findById(libro.getId()).orElse(null);
		libroexistente.setData(libro.getData());
		libroexistente.setEscritor(libro.getEscritor());
		libroexistente.setTitulo(libro.getTitulo());
		

          avaliativaRepository.save(libroexistente);
  		return "redirect:/index";
		
	}
	
	@RequestMapping(value="/pesquisar", method=RequestMethod.POST)
	public ModelAndView getLibrosByTitulo(@RequestParam("pesquisar") String pesquisar){
		ModelAndView mv = new ModelAndView("index");
		List<Libro> libro = avaliativaRepository.findLibrosByTituloLike("%"+pesquisar+"%");
		mv.addObject("libro", libro);
		return mv;
	}
	
	
		
	
	 @RequestMapping(value="libro/delete/{id}", method=RequestMethod.GET)
		public String deletePosts(@PathVariable("id") int id, RedirectAttributes attributes){
		 try {
		 avaliativaRepository.deleteById(id);
			attributes.addFlashAttribute("mensagem", "Deletado com sucesso");
		 }catch(Exception e) {
				attributes.addFlashAttribute("mensagem", "nao foi possivel deletar");
				return "redirect:/libro";

		 }
			return "redirect:/index";
		}

	
	
	
	
	
	
	
	/*Autor*/
	
	@RequestMapping(value="/autor",method=RequestMethod.GET)
	public ModelAndView getAutor() {
		ModelAndView mv= new ModelAndView("autores");
		List<Autor> autores=avaliativaRepositorydos.findAll();
		mv.addObject("autores",autores);
		return mv;
	}
	
	@RequestMapping(value="/autor/{id}",method=RequestMethod.GET)
	public ModelAndView getAutor(@PathVariable("id")int Id) {
		ModelAndView mv= new ModelAndView("autor");
		Optional<Autor> autor=avaliativaRepositorydos.findById(Id);
		mv.addObject("nome",autor.get().getNome());
		mv.addObject("titulo",autor.get().getGeneroliterario());
		mv.addObject("id",autor.get().getId());
		return mv;
		
	}
	
@RequestMapping(value="/buscar", method=RequestMethod.POST)
	public ModelAndView 
	getAutorByGeneros(@RequestParam("buscar") String buscar){
		ModelAndView mv = new ModelAndView("autores");
		List<Autor> autores = avaliativaRepositorydos.findAutorByGeneroliterarioLike("%"+buscar+"%");
		mv.addObject("autores", autores);
		return mv;
	}









	@RequestMapping(value="/saveautor",method=RequestMethod.GET)
	public String saveautor() {

		return "saveautor";
		
	}
	
	
	@RequestMapping(value="/saveautor",method=RequestMethod.POST)
	public String saveAutor(@Valid Autor autor ,BindingResult result, RedirectAttributes attributes) {
		
		if(result.hasErrors()) {
			attributes.addFlashAttribute("mensagem","Sucess");
			return "redirect:/saveautor";
			
		}
		
		avaliativaRepositorydos.save(autor);
		


	
		
		return "redirect:/autor";
	}
	
	@RequestMapping(value="/autor/UpdateAutor/{id}",method=RequestMethod.GET)
	public ModelAndView updatesAutor(@PathVariable("id")int id) {
		ModelAndView mv= new ModelAndView("updateAutor");
		Optional<Autor> Autor=avaliativaRepositorydos.findById(id);
		mv.addObject("autores",Autor);
		mv.addObject("nome",Autor.get().getNome());
		mv.addObject("sobrenome",Autor.get().getSobrenome());
		mv.addObject("generoliterario",Autor.get().getGeneroliterario());
		mv.addObject("id",Autor.get().getId());
		
		return mv;
		
	}
	
	@RequestMapping(value="/autor/UpdateAutor/{id}",method=RequestMethod.POST)
	public String updateAutor(Autor autor) {
		Autor autorexistente =avaliativaRepositorydos.findById(autor.getId()).orElse(null);
		autorexistente.setNome(autor.getNome());
		autorexistente.setSobrenome(autor.getSobrenome());
		autorexistente.setGeneroliterario(autor.getGeneroliterario());
		

          avaliativaRepositorydos.save(autorexistente);
  		return "redirect:/autor";
		
	}
	
	

	
	
	
	
	
	
	
	
	
	
	
	 @RequestMapping(value="autor/delete/{id}", method=RequestMethod.GET)
		public String deleteAutores(@PathVariable("id") int id, RedirectAttributes attributes){
		 try {
		 avaliativaRepositorydos.deleteById(id);
			attributes.addFlashAttribute("mensagem", "Deletado com sucesso");
		 }catch(Exception e) {
				attributes.addFlashAttribute("mensagem", "nao foi possivel deletar");
				return "redirect:/autor";

		 }
			return "redirect:/autor";
		}

	
}

	

