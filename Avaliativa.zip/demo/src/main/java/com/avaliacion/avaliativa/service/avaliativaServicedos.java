package com.avaliacion.avaliativa.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.avaliacion.avaliativa.model.Autor;

@Service
public interface avaliativaServicedos {
	Autor save(Autor autor);
	List<Autor> findAll();

	Autor findById(Integer id);
	Autor deleteById(int id);
    List<Autor> generoliterario(String generoliterario);
	
	
}


