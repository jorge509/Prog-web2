package com.avaliacion.avaliativa.repository;






import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avaliacion.avaliativa.model.Autor;

@Repository
public interface avaliativaRepositorydos extends JpaRepository<Autor, Integer> {
    List<Autor> findAutorBygeneroliterario(String generoliterario);


	
	
}



