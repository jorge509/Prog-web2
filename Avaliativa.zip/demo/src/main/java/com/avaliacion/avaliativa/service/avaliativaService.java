package com.avaliacion.avaliativa.service;

import java.util.List;

import com.avaliacion.avaliativa.model.Libro;

public interface avaliativaService {
List<Libro> findAll();
Libro findById(Integer id);
Libro save(Libro libro);
Libro deleteById(int id);
List<Libro> findLibrosByTipo(int tipo);

List<Libro> findLibrosByTituloLike(String titulo);
}
  