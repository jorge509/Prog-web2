package com.avaliacion.avaliativa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvaliativaApplicationTests {

	@Test
	void contextLoads() {
	}

}
