package com.ProyetoWeb2.ProyetoWeb2.Services.ServicesImplements;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ProyetoWeb2.ProyetoWeb2.Model.Posts;
import com.ProyetoWeb2.ProyetoWeb2.Repository.ProyetoWeb2Repository;
import com.ProyetoWeb2.ProyetoWeb2.Services.ProyetoWeb2Services;

@Service
public class ProyetoWeb2ServicesImplements  implements ProyetoWeb2Services{

	@Autowired
	ProyetoWeb2Repository repository;

 
	@Override
	public List<Posts> findAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Posts findById(Integer id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public Posts save(Posts posts) {
		// TODO Auto-generated method stub
		return repository.save(posts);
	}
	
	@Override
	public List<Posts> findPostsByTipo(int tipo) {
		// TODO Auto-generated method stub
		return repository.findPostsByTipo(tipo);
	}
	

	   @Override
		public Posts deleteById(int id) {
			return deleteById(id);
		}

	


	@Override
	public List<Posts> findPostsByTituloLike(String titulo) {
		// TODO Auto-generated method stub
		return repository.findPostsByTituloLike(titulo);
	}


	

}
