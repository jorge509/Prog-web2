package com.ProyetoWeb2.ProyetoWeb2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;//Import para quitar seguridad (loguin)

@SpringBootApplication(exclude= {SecurityAutoConfiguration.class})  ////Configuracion seguridad (pause)
//@SpringBootApplication
public class ProyetoWeb2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyetoWeb2Application.class, args);
	}

}
