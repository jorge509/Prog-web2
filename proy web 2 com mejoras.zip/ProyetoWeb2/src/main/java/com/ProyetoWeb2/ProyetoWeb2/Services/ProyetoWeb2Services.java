package com.ProyetoWeb2.ProyetoWeb2.Services;

import java.util.List;

import com.ProyetoWeb2.ProyetoWeb2.Model.Posts;

public interface ProyetoWeb2Services {
List<Posts> findAll();
Posts findById(Integer id);
Posts save(Posts posts);
List<Posts> findPostsByTipo(int tipo);
Posts deleteById(int id);
List<Posts> findPostsByTituloLike(String titulo);

}
