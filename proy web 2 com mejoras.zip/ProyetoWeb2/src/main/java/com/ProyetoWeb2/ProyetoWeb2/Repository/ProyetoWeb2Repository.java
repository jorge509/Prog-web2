package com.ProyetoWeb2.ProyetoWeb2.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ProyetoWeb2.ProyetoWeb2.Model.Posts;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProyetoWeb2Repository extends JpaRepository<Posts, Integer>{
    List<Posts> findPostsByTipo(int tipo);

    List<Posts> findPostsByTituloLike(String titulo);

}
