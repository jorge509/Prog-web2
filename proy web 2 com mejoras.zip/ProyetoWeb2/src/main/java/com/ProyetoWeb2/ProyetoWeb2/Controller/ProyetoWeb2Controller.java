package com.ProyetoWeb2.ProyetoWeb2.Controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ProyetoWeb2.ProyetoWeb2.Model.Posts;
import com.ProyetoWeb2.ProyetoWeb2.Repository.ProyetoWeb2Repository;



@Controller
public class ProyetoWeb2Controller {
	@Autowired
	 ProyetoWeb2Repository repository;

	@RequestMapping(value="/posts",method=RequestMethod.GET)
	public ModelAndView getPosts() {
		ModelAndView mv= new ModelAndView("index");
		List<Posts> posts=repository.findAll();
		mv.addObject("posts",posts);
		return mv;
		
	}
	@RequestMapping(value="/posts/{id}",method=RequestMethod.GET)
	public ModelAndView getPost(@PathVariable("id")int id) {
		ModelAndView mv= new ModelAndView("post");
		Optional<Posts> posts=repository.findById(id);
		mv.addObject("posts",posts);
		mv.addObject("autor",posts.get().getAutor());
		mv.addObject("titulo",posts.get().getTitulo());
		mv.addObject("data",posts.get().getData());
		mv.addObject("tipo",posts.get().getTipo());
		mv.addObject("texto",posts.get().getTexto());
		mv.addObject("id",posts.get().getId());
		return mv;
		
	}

	@RequestMapping(value="/save",method=RequestMethod.GET)
	public String save() {

		return "save";
		
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String savePost(@Valid Posts post ,BindingResult result, RedirectAttributes attributes, @RequestParam("img")MultipartFile img) {
		
		if(result.hasErrors()) {
			attributes.addFlashAttribute("mensagem","verifique os campos obrigatorios");
			return "redirect:/save";
		}
		
		post.setData(LocalDate.now());
		try {
			if(!img.isEmpty()) {
			byte[] bytes=img.getBytes();
			Path caminho=Paths.get("./src/main/resources/static/images/"+img.getOriginalFilename());
			Files.write(caminho, bytes);
		post.setImage(img.getOriginalFilename());
		
			}
			} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("erro na imagen");
		}
		repository.save(post);
		attributes.addFlashAttribute("mensagem","Sucess");
		return "redirect:/posts";
	}
	
	
	
	
	
	@RequestMapping(value="/posts/tipo/{id}", method=RequestMethod.GET)
	public ModelAndView getPostagemById(@PathVariable("id") int id){
		ModelAndView mv = new ModelAndView("index");
		List<Posts> posts = repository.findPostsByTipo(id);
		mv.addObject("posts", posts);
		return mv;
	}
	
	
	@RequestMapping(value="/posts/update/{id}",method=RequestMethod.GET)
	public ModelAndView updatePosts(@PathVariable("id")int id) {
		ModelAndView mv= new ModelAndView("update");
		Optional<Posts> posts=repository.findById(id);
		mv.addObject("posts",posts);
		mv.addObject("autor",posts.get().getAutor());
		mv.addObject("titulo",posts.get().getTitulo());
		mv.addObject("data",posts.get().getData());
		mv.addObject("tipo",posts.get().getTipo());
		mv.addObject("texto",posts.get().getTexto());
		mv.addObject("id",posts.get().getId());
		return mv;
		
	}
	
	@RequestMapping(value="/posts/update/{id}",method=RequestMethod.POST)
	public String updatePost(Posts posts) {
		Posts postexistente =repository.findById(posts.getId()).orElse(null);
		postexistente.setTipo(posts.getTipo());
		postexistente.setAutor(posts.getAutor());
		postexistente.setTitulo(posts.getTitulo());
		postexistente.setTexto(posts.getTexto());

          repository.save(postexistente);
  		return "redirect:/posts";
		
	}
	
	
	
	
	@RequestMapping(value="/pesquisar", 
			method=RequestMethod.POST)
	public ModelAndView 
	getPostsByTitulo(@RequestParam("pesquisar") String pesquisar){
		ModelAndView mv = new ModelAndView("index");
		List<Posts> posts = repository.findPostsByTituloLike("%"+pesquisar+"%");
		mv.addObject("posts", posts);
		return mv;
	}
	
	
	

	
	
	 @RequestMapping(value="posts/delete/{id}", method=RequestMethod.GET)
		public String deletePosts(@PathVariable("id") int id, RedirectAttributes attributes){
		 try {
		 repository.deleteById(id);
			attributes.addFlashAttribute("mensagem", "Deletado com sucesso");
		 }catch(Exception e) {
				attributes.addFlashAttribute("mensagem", "nao foi possivel deletar");
				return "redirect:/posts";

		 }
			return "redirect:/posts";
		}
	
	 
	 
	 
	 
	
	
	


}
