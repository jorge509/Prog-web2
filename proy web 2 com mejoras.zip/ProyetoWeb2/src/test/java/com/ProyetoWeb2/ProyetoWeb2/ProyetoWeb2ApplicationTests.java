package com.ProyetoWeb2.ProyetoWeb2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyetoWeb2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
